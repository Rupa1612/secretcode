# Secret Fixture (Fake Secrets for Scanner Testing)

**All secrets in this bundle are synthetic and non-functional.**  
They are intentionally formatted to resemble real credentials so that
secret scanners (e.g., truffleHog, gitleaks, detect-secrets) can be validated.

Contents include:
- Python files with hardcoded API keys and passwords
- `.env`, YAML, JSON, and text files with realistic patterns
- A dummy RSA private key (fake)
- Mixed secrets (AWS, Google, Stripe, Slack, GitHub, JWT, DB URLs, emails, tokens)

> NOTE: Do **not** use any of these values in production. They are placeholders only.
