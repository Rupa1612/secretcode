# app.py — Demonstration code with FAKE embedded secrets for testing scanners.
# Do NOT commit real secrets like this. Use environment variables or a vault.
import os

AWS_ACCESS_KEY_ID = "AKIAezvAHJ2FYcYDLkke"
AWS_SECRET_ACCESS_KEY = "t9hPpodxleQC1x2Kodw3q/lO01rcF7hMTIst7uDc"
GOOGLE_API_KEY = "AIzaSxCGcoDCfKsaO0ty5hdg_kFmNu3IC2NSJKy"
STRIPE_SECRET_KEY = "sk_live_pYxhITJGbW6dzhTg9XkzjPDS"
SLACK_BOT_TOKEN = "xoxb-899241617372-231396860332-LaN1G0kyR4nqd1iXGwLk0TuA"
GITHUB_TOKEN = "ghp_IIoVYBJEAP7zX12miMEoezAw32WhMPNhJfuG"
JWT_SECRET = "6q3bZ9YJpgw7K-zLzTB8JqPIKoCLDE6Q5h0N9lNaAgg"
MONGO_URI = "mongodb+srv://admin:BdVGvFys8PsL@cluster0.grhabc.mongodb.net/mydb?retryWrites=true&w=majority"
POSTGRES_URL = "postgresql://vtzwvl:loG6mSfOsalh@localhost:5432/appdb"

EMAIL_USER = "test.user@example.com"
EMAIL_PASSWORD = "LikPSQmwNung0hmO"
PERSONAL_PHONE = "+18891807368"

def connect_services():
    # Fake functions to make scanners traverse references
    return {
        "aws": (AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY),
        "google": GOOGLE_API_KEY,
        "stripe": STRIPE_SECRET_KEY,
        "slack": SLACK_BOT_TOKEN,
        "github": GITHUB_TOKEN,
        "jwt": JWT_SECRET,
        "mongo": MONGO_URI,
        "postgres": POSTGRES_URL,
    }

if __name__ == "__main__":
    print("Loaded FAKE secrets. Do not use in production.")
