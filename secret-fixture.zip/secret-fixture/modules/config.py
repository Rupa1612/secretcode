# modules/config.py — another place secrets sometimes hide (FAKE)
TWILIO_SID = "ACIoRDSk9z6WB3icsHUsW3OenIZgPBjJdt"
TWILIO_AUTH_TOKEN = "IoehatNz1PPd4ekgkx1o237ezTmvh7ui"
SMTP_PASSWORD = "EYKpTLTPvL2gCtIk63"
DEBUG_LOGIN = {"username": "admin", "password": "WXytVKxenb"}
