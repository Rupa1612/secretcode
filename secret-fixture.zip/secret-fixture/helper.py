# helper.py — FAKE secret usage
from modules.config import TWILIO_SID, TWILIO_AUTH_TOKEN, SMTP_PASSWORD
def dial():
    return TWILIO_SID, TWILIO_AUTH_TOKEN, SMTP_PASSWORD
